# Freezeit 冻它

**[面具模块]** 实现部分墓碑机制，自动暂停后台进程的运行。

**[MagiskModule]** Implement a partial tombstone mechanism to automatically suspend background processes.

---

[教程 Tutorials](https://jark006.github.io/FreezeitIntroduction/)

[酷安 @JARK006](https://www.coolapk.com/u/1212220) 

[QQ群组 781222669](https://jq.qq.com/?_wv=1027&k=Q5aVUglt)

[Telegram Group](https://t.me/+sjDX1oTk31ZmYjY1)

[蓝奏云下载](https://jark006.lanzout.com/b017oz9if) 密码: dy6i

---

